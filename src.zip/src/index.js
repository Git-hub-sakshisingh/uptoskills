// import React from 'react';
// import ReactDOM from 'react-dom/client';
// import './index.css';
// import App from './App';


// const root = ReactDOM.createRoot(document.getElementById('root'));
// root.render(
//   <React.StrictMode>
//     <App />
//   </React.StrictMode>
// );

import React from 'react';
import ReactDOM from 'react-dom/client';  // Use 'react-dom/client' in React 18+
import { Provider } from 'react-redux';
import store from './Redux/Store';
import App from './App';  // Your main app component

const root = ReactDOM.createRoot(document.getElementById('root'));  // Create root using createRoot

root.render(
  <Provider store={store}>  {/* Wrap App in Provider and pass the store */}
    <App />
  </Provider>
);

