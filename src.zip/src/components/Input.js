// import React, { useEffect, useState } from "react";
// import { BsFillPlusCircleFill } from "react-icons/bs";
// import { RiCloseFill } from "react-icons/ri";
// import { useNavigate } from "react-router-dom";
// import { useForm, useFieldArray } from "react-hook-form";
// import "./Input.css";
// import Loading from "./Loading";
// import Classic from "../Themes/Classic";

// function Input() {
//   const [loading, setLoading] = useState(true);
// //   const [userData, setUserData] = useState(null);

//   const navigate = useNavigate();

//   // Default form data structure
//   const emptydata = {
//     experience: [{
//       company: "", description: "", worktitle: "", tags: "", yearfrom: "", yearto: "", present: false
//     }],
//     course: [{
//       name: "", provider: "", certificate: "", year: ""
//     }],
//     education: [{
//       degree: "", grade: "", university: "", yearfrom: "", yearto: "", gradetype: "percentage"
//     }],
//     personal: {
//       technicalskill: [{
//         skill: "", rate: ""
//       }],
//       interest: [{
//         hobbie: ""
//       }],
//       languages: [{
//         language: "", proficiency: ""
//       }],
//       awards: [{
//         name: "", year: "", description: ""
//       }],
//       name: "", lastname: "", date: "", email: "", mob: "",
//       city: "", country: "", image: "",
//       title: "", quote: ""
//     },
//     project: [{
//       name: "", tech: "", des: "", link: ""
//     }],
//     link: {
//       linkedin: "",
//       github: "",
//       portfolio: ""
//     },
//   };

//   // Using React Hook Form to manage form state
//   const { register, handleSubmit, control, formState: { errors }, reset } = useForm({
//     defaultValues: emptydata
//   });

//   // Managing dynamic fields (using useFieldArray)
//   const { fields: languagesFields, append: languagesAppend, remove: languagesRemove } = useFieldArray({
//     control, name: "personal.languages"
//   });

//   const { fields: awardsFields, append: awardsAppend, remove: awardsRemove } = useFieldArray({
//     control, name: "personal.awards"
//   });

//   const { fields: experienceFields, append: experienceAppend, remove: experienceRemove } = useFieldArray({
//     control, name: "experience"
//   });

//   const { fields: educationFields, append: educationAppend, remove: educationRemove } = useFieldArray({
//     control, name: "education"
//   });

//   const { fields: courseFields, append: courseAppend, remove: courseRemove } = useFieldArray({
//     control, name: "course"
//   });

//   const { fields: projectFields, append: projectAppend, remove: projectRemove } = useFieldArray({
//     control, name: "project"
//   });

//   const loadFunc = () => {
//     setLoading(true);
//     setTimeout(() => {
//       setLoading(false);
//     }, 1000);
//   };

//   useEffect(() => {
//     window.scrollTo({ top: 0, left: 0, behavior: "smooth" });
//     loadFunc();
//   }, []);

//   // Handle form submission
//   const onSubmit = async (data) => {
//     try {
//         // setUserData(data);
//       const response = await fetch("http://localhost:5000/api/formdata", {
//         method: "POST",
//         headers: {
//           "Content-Type": "application/json",
//         },
//         body: JSON.stringify(data)
       
//       });
//       if (response.ok) {
//         navigate("/selecttheme");
//       } else {
//         alert("Failed to submit data.");
//       }
//     } catch (error) {
//       console.error(error);
//       alert("Error submitting data.");
//     }
//   };

//   // Reset form
//   const clrFunc = () => {
//     reset(emptydata);
//   };

//   return (
//     <>
//       {loading ? <Loading /> :
//         <>
//           <div className="input-header">Enter your details</div>
//           <div className="input-main">
//             <form className="input-form" onSubmit={handleSubmit(onSubmit)}>

//               {/* Personal Details Section */}
//               <div className="input-head">Personal Details</div>
//               <input className="input-field" {...register("personal.name", { required: true })} placeholder="First Name" />
//               <input className="input-field" {...register("personal.lastname", { required: true })} placeholder="Last Name" />
//               <input className="input-field" type="number" inputMode="tel" {...register("personal.mob", { maxLength: 10, required: true })} placeholder="Mobile No- +91" />
//               <input className="input-field" type="email" inputMode="email" {...register("personal.email", { required: true })} placeholder="Email" />
//               <input className="input-field" {...register("personal.city", { required: true })} placeholder="City" />
//               <input className="input-field" {...register("personal.country", { required: true })} placeholder="Country" />
//               <input className="input-field" {...register("personal.title", { required: true })} placeholder="Professional Title e.g Full Stack Developer" />
//               <input className="input-field" {...register("personal.quote", { required: true })} placeholder="Professional Summary" />

//               {/* Skills and Interests Section */}
//               <div className="input-head">Interest/Skills</div>
//               {emptydata.personal.technicalskill.map((skill, index) => (
//                 <div key={index} className="input-group">
//                   <input className="input-field" {...register(`personal.technicalskill[${index}].skill`, { required: true })} placeholder="Skill" />
//                   <input className="input-field" type="number" min="1" max="5" {...register(`personal.technicalskill[${index}].rate`, { required: true })} placeholder="Proficiency (1-5)" />
//                 </div>
//               ))}

//               {/* Work Experience Section */}
//               <div className="input-head">Work Experience</div>
//               {experienceFields.map((item, index) => (
//                 <React.Fragment key={item.id}>
//                   <input className="input-field" {...register(`experience[${index}].company`, { required: true })} defaultValue={item.company} placeholder="Company Name" />
//                   <input className="input-field" {...register(`experience[${index}].worktitle`, { required: true })} defaultValue={item.worktitle} placeholder="Job Title" />
//                   <input className="input-field" type="number" {...register(`experience[${index}].yearfrom`, { required: true })} defaultValue={item.yearfrom} placeholder="Year From" />
//                   <input className="input-field" type="number" {...register(`experience[${index}].yearto`, { required: true })} defaultValue={item.yearto} placeholder="Year To" />
//                   <input className="input-field" {...register(`experience[${index}].description`, { required: true })} defaultValue={item.description} placeholder="Description" />
//                   {index !== 0 && <RiCloseFill onClick={() => experienceRemove(index)} className="remove-icon" />}
//                 </React.Fragment>
//               ))}
//               <div className="add-input-block">
//                 <BsFillPlusCircleFill className="add-input-icon" onClick={() => experienceAppend({ company: "", worktitle: "", yearfrom: "", yearto: "", description: "" })} />
//               </div>

//               {/* Education Section */}
//               <div className="input-head">Education</div>
//               {educationFields.map((item, index) => (
//                 <React.Fragment key={item.id}>
//                   <input className="input-field" {...register(`education[${index}].degree`, { required: true })} defaultValue={item.degree} placeholder="Degree" />
//                   <input className="input-field" {...register(`education[${index}].university`, { required: true })} defaultValue={item.university} placeholder="University" />
//                   <input className="input-field" type="number" {...register(`education[${index}].yearfrom`, { required: true })} defaultValue={item.yearfrom} placeholder="Year From" />
//                   <input className="input-field" type="number" {...register(`education[${index}].yearto`, { required: true })} defaultValue={item.yearto} placeholder="Year To" />
//                   <input className="input-field" {...register(`education[${index}].grade`, { required: true })} defaultValue={item.grade} placeholder="Grade" />
//                   {index !== 0 && <RiCloseFill onClick={() => educationRemove(index)} className="remove-icon" />}
//                 </React.Fragment>
//               ))}
//               <div className="add-input-block">
//                 <BsFillPlusCircleFill className="add-input-icon" onClick={() => educationAppend({ degree: "", university: "", yearfrom: "", yearto: "", grade: "" })} />
//               </div>

//               {/* Course Section */}
//               <div className="input-head">Courses</div>
//               {courseFields.map((item, index) => (
//                 <React.Fragment key={item.id}>
//                   <input className="input-field" {...register(`course[${index}].name`, { required: true })} defaultValue={item.name} placeholder="Course Name" />
//                   <input className="input-field" {...register(`course[${index}].provider`, { required: true })} defaultValue={item.provider} placeholder="Provider" />
//                   <input className="input-field" {...register(`course[${index}].certificate`, { required: true })} defaultValue={item.certificate} placeholder="Certificate" />
//                   <input className="input-field" type="number" {...register(`course[${index}].year`, { required: true })} defaultValue={item.year} placeholder="Year" />
//                   {index !== 0 && <RiCloseFill onClick={() => courseRemove(index)} className="remove-icon" />}
//                 </React.Fragment>
//               ))}
//               <div className="add-input-block">
//                 <BsFillPlusCircleFill className="add-input-icon" onClick={() => courseAppend({ name: "", provider: "", certificate: "", year: "" })} />
//               </div>

//               {/* Project Section */}
//               <div className="input-head">Projects</div>
//               {projectFields.map((item, index) => (
//                 <React.Fragment key={item.id}>
//                   <input className="input-field" {...register(`project[${index}].name`, { required: true })} defaultValue={item.name} placeholder="Project Name" />
//                   <input className="input-field" {...register(`project[${index}].tech`, { required: true })} defaultValue={item.tech} placeholder="Technologies" />
//                   <input className="input-field" {...register(`project[${index}].des`, { required: true })} defaultValue={item.des} placeholder="Description" />
//                   <input className="input-field" {...register(`project[${index}].link`, { required: true })} defaultValue={item.link} placeholder="Project Link" />
//                   {index !== 0 && <RiCloseFill onClick={() => projectRemove(index)} className="remove-icon" />}
//                 </React.Fragment>
//               ))}
//               <div className="add-input-block">
//                 <BsFillPlusCircleFill className="add-input-icon" onClick={() => projectAppend({ name: "", tech: "", des: "", link: "" })} />
//               </div>

//               {/* Links Section */}
//               <div className="input-head">Links</div>
//               <input className="input-field" {...register("link.linkedin")} placeholder="LinkedIn" />
//               <input className="input-field" {...register("link.github")} placeholder="GitHub" />
//               <input className="input-field" {...register("link.portfolio")} placeholder="Portfolio" />

//               {/* Submit and Clear Buttons */}
//               <div className="singlefield btndiv mt-3">
//                 <input className="input-btn" type="button" value="Clear All" onClick={clrFunc} />
//                 <input className="input-btn" type="submit" value="Next" />
//               </div>
//             </form>
//           </div>
//         </>}
//         {/* {userData && <Classic userData={userData} />} */}
//         {/* {userData && userData.personal && <Classic userData={userData} />} */}

//     </>
//   );


  

// }

// export default Input;




// import React, { useState } from 'react';
// import { useNavigate } from 'react-router-dom';
// import './Input.css'; // Add any styling for your input form here

// function Input() {



//   const [formData, setFormData] = useState({
//     personal: {
//       name: '',
//       lastname: '',
//       title: '',
//       quote: '',
//       email: '',
//       mob: '',
//       city: '',
//       country: '',
//       technicalskill: [],
//       interest: [],
//     },
//     link: {
//       linkedin: '',
//       github: '',
//     },
//     experience: [],
//     education: [],
//     project: [],
//     course: [],
//   });

//   const navigate = useNavigate();

//   // Handle input change for text fields
//   const handleInputChange = (e) => {
//     const { name, value } = e.target;
//     setFormData((prevData) => ({
//       ...prevData,
//       personal: {
//         ...prevData.personal,
//         [name]: value,
//       },
//     }));
//   };

//   // Handle input change for technical skills
//   const handleTechnicalSkillsChange = (e) => {
//     const { value } = e.target;
//     setFormData((prevData) => ({
//       ...prevData,
//       personal: {
//         ...prevData.personal,
//         technicalskill: value.split(',').map((skill) => ({ skill })),
//       },
//     }));
//   };

//   // Handle input change for hobbies/interests
//   const handleInterestChange = (e) => {
//     const { value } = e.target;
//     setFormData((prevData) => ({
//       ...prevData,
//       personal: {
//         ...prevData.personal,
//         interest: value.split(',').map((hobbie) => ({ hobbie })),
//       },
//     }));
//   };

//   // Handle experience fields
//   const handleExperienceChange = (index, e) => {
//     const { name, value } = e.target;
//     const updatedExperience = [...formData.experience];
//     updatedExperience[index] = { ...updatedExperience[index], [name]: value };
//     setFormData({ ...formData, experience: updatedExperience });
//   };

//   const addExperience = () => {
//     setFormData({
//       ...formData,
//       experience: [
//         ...formData.experience,
//         { company: '', worktitle: '', yearfrom: '', yearto: '', description: '', present: false },
//       ],
//     });
//   };

//   // Handle education fields
//   const handleEducationChange = (index, e) => {
//     const { name, value } = e.target;
//     const updatedEducation = [...formData.education];
//     updatedEducation[index] = { ...updatedEducation[index], [name]: value };
//     setFormData({ ...formData, education: updatedEducation });
//   };

//   const addEducation = () => {
//     setFormData({
//       ...formData,
//       education: [
//         ...formData.education,
//         { degree: '', university: '', yearfrom: '', yearto: '', grade: '', gradetype: 'grade' },
//       ],
//     });
//   };

//   // Handle project fields
//   const handleProjectChange = (index, e) => {
//     const { name, value } = e.target;
//     const updatedProjects = [...formData.project];
//     updatedProjects[index] = { ...updatedProjects[index], [name]: value };
//     setFormData({ ...formData, project: updatedProjects });
//   };

//   const addProject = () => {
//     setFormData({
//       ...formData,
//       project: [
//         ...formData.project,
//         { name: '', tech: '', des: '' },
//       ],
//     });
//   };

//   // Handle course fields
//   const handleCourseChange = (index, e) => {
//     const { name, value } = e.target;
//     const updatedCourses = [...formData.course];
//     updatedCourses[index] = { ...updatedCourses[index], [name]: value };
//     setFormData({ ...formData, course: updatedCourses });
//   };

//   const addCourse = () => {
//     setFormData({
//       ...formData,
//       course: [
//         ...formData.course,
//         { name: '', provider: '' },
//       ],
//     });
//   };

// //   const handleSubmit = (e) => {
// //     e.preventDefault();
// //     navigate('/classictheme', { state: formData });  // Passing form data to Classic.js via React Router state
// //   };


//    // Handle form submission
// //   const handleSubmit = async (data) => {
// //     try {
// //       const response = await fetch("http://localhost:5000/api/formdata", {
// //         method: "POST",
// //         headers: {
// //           "Content-Type": "application/json",
// //         },
// //         body: JSON.stringify(data)
       
// //       });
// //       if (response.ok) {
// //         navigate("/selecttheme");
// //       } else {
// //         alert("Failed to submit data.");
// //       }
// //     } catch (error) {
// //       console.error(error);
// //       alert("Error submitting data.");
// //     }
// //   };
// const handleSubmit = async (e) => {
//     e.preventDefault();

//     // Sending data to MongoDB via Express
//     try {
//       const response = await fetch('http://localhost:5000/api/formdata', {
//         method: 'POST',
//         headers: {
//           'Content-Type': 'application/json',
//         },
//         body: JSON.stringify(formData),
//       });

//       const data = await response.json();

//       if (response.status === 201) {
//         // Success, navigate to Classic.js page
//         navigate('/classictheme', { state: formData });
//       } else {
//         console.error('Error:', data.message);
//       }
//     } catch (error) {
//       console.error('Error submitting resume data:', error);
//     }
//   };

//   return (
//     <div className="input-form-container">
//       <h2>Create Your Resume</h2>
//       <form onSubmit={handleSubmit}>
//         <div className="section">
//           <h3>Personal Details</h3>
//           <input
//             type="text"
//             name="name"
//             value={formData.personal.name}
//             onChange={handleInputChange}
//             placeholder="First Name"
//             required
//           />
//           <input
//             type="text"
//             name="lastname"
//             value={formData.personal.lastname}
//             onChange={handleInputChange}
//             placeholder="Last Name"
//             required
//           />
//           <input
//             type="text"
//             name="title"
//             value={formData.personal.title}
//             onChange={handleInputChange}
//             placeholder="Job Title"
//             required
//           />
//           <textarea
//             name="quote"
//             value={formData.personal.quote}
//             onChange={handleInputChange}
//             placeholder="Quote"
//             required
//           />
//           <input
//             type="email"
//             name="email"
//             value={formData.personal.email}
//             onChange={handleInputChange}
//             placeholder="Email"
//             required
//           />
//           <input
//             type="text"
//             name="mob"
//             value={formData.personal.mob}
//             onChange={handleInputChange}
//             placeholder="Mobile Number"
//             required
//           />
//           <input
//             type="text"
//             name="city"
//             value={formData.personal.city}
//             onChange={handleInputChange}
//             placeholder="City"
//             required
//           />
//           <input
//             type="text"
//             name="country"
//             value={formData.personal.country}
//             onChange={handleInputChange}
//             placeholder="Country"
//             required
//           />
//         </div>

//         <div className="section">
//           <h3>Technical Skills</h3>
//           <textarea
//             name="technicalskill"
//             value={formData.personal.technicalskill.map((skill) => skill.skill).join(', ')}
//             onChange={handleTechnicalSkillsChange}
//             placeholder="Enter skills separated by commas (e.g. JavaScript, React)"
//             required
//           />
//         </div>

//         <div className="section">
//           <h3>Interests / Hobbies</h3>
//           <textarea
//             name="interest"
//             value={formData.personal.interest.map((hobbie) => hobbie.hobbie).join(', ')}
//             onChange={handleInterestChange}
//             placeholder="Enter hobbies separated by commas (e.g. Reading, Coding)"
//             required
//           />
//         </div>

//         {/* Experience Section */}
//         <div className="section">
//           <h3>Work Experience</h3>
//           {formData.experience.map((exp, index) => (
//             <div key={index}>
//               <input
//                 type="text"
//                 name="company"
//                 value={exp.company}
//                 onChange={(e) => handleExperienceChange(index, e)}
//                 placeholder="Company"
//                 required
//               />
//               <input
//                 type="text"
//                 name="worktitle"
//                 value={exp.worktitle}
//                 onChange={(e) => handleExperienceChange(index, e)}
//                 placeholder="Job Title"
//                 required
//               />
//               <input
//                 type="text"
//                 name="yearfrom"
//                 value={exp.yearfrom}
//                 onChange={(e) => handleExperienceChange(index, e)}
//                 placeholder="From Year"
//                 required
//               />
//               <input
//                 type="text"
//                 name="yearto"
//                 value={exp.yearto}
//                 onChange={(e) => handleExperienceChange(index, e)}
//                 placeholder="To Year"
//                 required
//               />
//               <textarea
//                 name="description"
//                 value={exp.description}
//                 onChange={(e) => handleExperienceChange(index, e)}
//                 placeholder="Job Description"
//                 required
//               />
//               <label>
//                 Present:
//                 <input
//                   type="checkbox"
//                   name="present"
//                   checked={exp.present}
//                   onChange={(e) => {
//                     const updatedExperience = [...formData.experience];
//                     updatedExperience[index].present = e.target.checked;
//                     setFormData({ ...formData, experience: updatedExperience });
//                   }}
//                 />
//               </label>
//             </div>
//           ))}
//           <button type="button" onClick={addExperience}>Add Experience</button>
//         </div>

//         {/* Education Section */}
//         <div className="section">
//           <h3>Education</h3>
//           {formData.education.map((edu, index) => (
//             <div key={index}>
//               <input
//                 type="text"
//                 name="degree"
//                 value={edu.degree}
//                 onChange={(e) => handleEducationChange(index, e)}
//                 placeholder="Degree"
//                 required
//               />
//               <input
//                 type="text"
//                 name="university"
//                 value={edu.university}
//                 onChange={(e) => handleEducationChange(index, e)}
//                 placeholder="University"
//                 required
//               />
//               <input
//                 type="text"
//                 name="yearfrom"
//                 value={edu.yearfrom}
//                 onChange={(e) => handleEducationChange(index, e)}
//                 placeholder="From Year"
//                 required
//               />
//               <input
//                 type="text"
//                 name="yearto"
//                 value={edu.yearto}
//                 onChange={(e) => handleEducationChange(index, e)}
//                 placeholder="To Year"
//                 required
//               />
//               <input
//                 type="text"
//                 name="grade"
//                 value={edu.grade}
//                 onChange={(e) => handleEducationChange(index, e)}
//                 placeholder="Grade"
//                 required
//               />
//               <select
//                 name="gradetype"
//                 value={edu.gradetype}
//                 onChange={(e) => handleEducationChange(index, e)}
//               >
//                 <option value="grade">Grade</option>
//                 <option value="percentage">Percentage</option>
//               </select>
//             </div>
//           ))}
//           <button type="button" onClick={addEducation}>Add Education</button>
//         </div>

//         {/* Project Section */}
//         <div className="section">
//           <h3>Projects</h3>
//           {formData.project.map((proj, index) => (
//             <div key={index}>
//               <input
//                 type="text"
//                 name="name"
//                 value={proj.name}
//                 onChange={(e) => handleProjectChange(index, e)}
//                 placeholder="Project Name"
//                 required
//               />
//               <input
//                 type="text"
//                 name="tech"
//                 value={proj.tech}
//                 onChange={(e) => handleProjectChange(index, e)}
//                 placeholder="Technologies"
//                 required
//               />
//               <textarea
//                 name="des"
//                 value={proj.des}
//                 onChange={(e) => handleProjectChange(index, e)}
//                 placeholder="Project Description"
//                 required
//               />
//             </div>
//           ))}
//           <button type="button" onClick={addProject}>Add Project</button>
//         </div>

//         {/* Course Section */}
//         <div className="section">
//           <h3>Courses</h3>
//           {formData.course.map((course, index) => (
//             <div key={index}>
//               <input
//                 type="text"
//                 name="name"
//                 value={course.name}
//                 onChange={(e) => handleCourseChange(index, e)}
//                 placeholder="Course Name"
//                 required
//               />
//               <input
//                 type="text"
//                 name="provider"
//                 value={course.provider}
//                 onChange={(e) => handleCourseChange(index, e)}
//                 placeholder="Course Provider"
//                 required
//               />
//             </div>
//           ))}
//           <button type="button" onClick={addCourse}>Add Course</button>
//         </div>

//         <button type="submit" onclick={handleSubmit}>Generate Resume</button>
//       </form>
//     </div>
//   );
// }

// export default Input;




import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './Input.css';

function Input() {

  const [formData, setFormData] = useState({
    personal: {
      name: '',
      lastname: '',
      title: '',
      quote: '',
      email: '',
      mob: '',
      city: '',
      country: '',
      technicalskill: [],
      interest: [],
    },
    link: {
      linkedin: '',
      github: '',
    },
    experience: [],
    education: [],
    project: [],
    course: [],
  });

  const navigate = useNavigate();

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      personal: {
        ...prevData.personal,
        [name]: value,
      },
    }));
  };

  const handleTechnicalSkillsChange = (e) => {
    const { value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      personal: {
        ...prevData.personal,
        technicalskill: value.split(',').map((skill) => ({ skill })),
      },
    }));
  };

  const handleInterestChange = (e) => {
    const { value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      personal: {
        ...prevData.personal,
        interest: value.split(',').map((hobbie) => ({ hobbie })),
      },
    }));
  };

  const handleExperienceChange = (index, e) => {
    const { name, value } = e.target;
    const updatedExperience = [...formData.experience];
    updatedExperience[index] = { ...updatedExperience[index], [name]: value };
    setFormData({ ...formData, experience: updatedExperience });
  };

  const addExperience = () => {
    setFormData({
      ...formData,
      experience: [
        ...formData.experience,
        { company: '', worktitle: '', yearfrom: '', yearto: '', description: '', present: false },
      ],
    });
  };

  const handleEducationChange = (index, e) => {
    const { name, value } = e.target;
    const updatedEducation = [...formData.education];
    updatedEducation[index] = { ...updatedEducation[index], [name]: value };
    setFormData({ ...formData, education: updatedEducation });
  };

  const addEducation = () => {
    setFormData({
      ...formData,
      education: [
        ...formData.education,
        { degree: '', university: '', yearfrom: '', yearto: '', grade: '', gradetype: 'grade' },
      ],
    });
  };

  const handleProjectChange = (index, e) => {
    const { name, value } = e.target;
    const updatedProjects = [...formData.project];
    updatedProjects[index] = { ...updatedProjects[index], [name]: value };
    setFormData({ ...formData, project: updatedProjects });
  };

  const addProject = () => {
    setFormData({
      ...formData,
      project: [
        ...formData.project,
        { name: '', tech: '', des: '' },
      ],
    });
  };

  const handleCourseChange = (index, e) => {
    const { name, value } = e.target;
    const updatedCourses = [...formData.course];
    updatedCourses[index] = { ...updatedCourses[index], [name]: value };
    setFormData({ ...formData, course: updatedCourses });
  };

  const addCourse = () => {
    setFormData({
      ...formData,
      course: [
        ...formData.course,
        { name: '', provider: '' },
      ],
    });
  };



// const handleSubmit = async (e) => {
//         e.preventDefault();
    
//         // Sending data to MongoDB via Express
//         try {
//           const response = await fetch('http://localhost:5000/api/formdata', {
//             method: 'POST',
//             headers: {
//               'Content-Type': 'application/json',
//             },
//             body: JSON.stringify(formData),
//           });
    
//           const data = await response.json();
    
//           if (response.status === 201) {
//             // Success, navigate to Classic.js page
//             navigate('/classictheme', { state: formData });
//           } else {
//             console.error('Error:', data.message);
//           }
//         } catch (error) {
//           console.error('Error submitting resume data:', error);
//         }
//       };
const handleSubmit = async (e) => {
    e.preventDefault();
  
    // Optionally, you can add a loading state here to show user progress
    try {
      const response = await fetch('http://localhost:5000/api/formdata', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData),
      });
  
      // Handle the response (Check if it's okay before proceeding)
      if (!response.ok) {
        // If the response is not OK, we throw an error
        throw new Error('Error submitting data');
      }
  
      const data = await response.json();  // Convert response to JSON
  
      // Check for success
      if (data.message === 'Data saved successfully') {
        // If the data is saved successfully, navigate to the next page
        navigate('/classictheme', { state: formData });
      } else {
        // If there's an issue, log the message
        console.error('Error:', data.message);
      }
    } catch (error) {
      // Catch any errors during the fetch or JSON processing
      console.error('Error submitting resume data:', error);
    }
  };
  
  return (
    <div className="input-form-container">
      <h2 className="form-title">Create Your Resume</h2>
      <form onSubmit={handleSubmit}>
        <div className="form-section">
          <h3>Personal Details</h3>
          <input
            className="form-input"
            type="text"
            name="name"
            value={formData.personal.name}
            onChange={handleInputChange}
            placeholder="First Name"
            required
          />
          <input
            className="form-input"
            type="text"
            name="lastname"
            value={formData.personal.lastname}
            onChange={handleInputChange}
            placeholder="Last Name"
            required
          />
          <input
            className="form-input"
            type="text"
            name="title"
            value={formData.personal.title}
            onChange={handleInputChange}
            placeholder="Job Title"
            required
          />
          <textarea
            className="form-textarea"
            name="quote"
            value={formData.personal.quote}
            onChange={handleInputChange}
            placeholder="Quote"
            required
          />
          <input
            className="form-input"
            type="email"
            name="email"
            value={formData.personal.email}
            onChange={handleInputChange}
            placeholder="Email"
            required
          />
          <input
            className="form-input"
            type="text"
            name="mob"
            value={formData.personal.mob}
            onChange={handleInputChange}
            placeholder="Mobile Number"
            required
          />
          <input
            className="form-input"
            type="text"
            name="city"
            value={formData.personal.city}
            onChange={handleInputChange}
            placeholder="City"
            required
          />
          <input
            className="form-input"
            type="text"
            name="country"
            value={formData.personal.country}
            onChange={handleInputChange}
            placeholder="Country"
            required
          />
        </div>

        <div className="form-section">
          <h3>Technical Skills</h3>
          <textarea
            className="form-textarea"
            name="technicalskill"
            value={formData.personal.technicalskill.map((skill) => skill.skill).join(', ')}
            onChange={handleTechnicalSkillsChange}
            placeholder="Enter skills separated by commas (e.g. JavaScript, React)"
            required
          />
        </div>

        <div className="form-section">
          <h3>Interests / Hobbies</h3>
          <textarea
            className="form-textarea"
            name="interest"
            value={formData.personal.interest.map((hobbie) => hobbie.hobbie).join(', ')}
            onChange={handleInterestChange}
            placeholder="Enter hobbies separated by commas (e.g. Reading, Coding)"
            required
          />
        </div>

        {/* Experience Section */}
        <div className="form-section">
          <h3>Work Experience</h3>
          {formData.experience.map((exp, index) => (
            <div className="experience-item" key={index}>
              <input
                className="form-input"
                type="text"
                name="company"
                value={exp.company}
                onChange={(e) => handleExperienceChange(index, e)}
                placeholder="Company"
                required
              />
              <input
                className="form-input"
                type="text"
                name="worktitle"
                value={exp.worktitle}
                onChange={(e) => handleExperienceChange(index, e)}
                placeholder="Job Title"
                required
              />
              <input
                className="form-input"
                type="text"
                name="yearfrom"
                value={exp.yearfrom}
                onChange={(e) => handleExperienceChange(index, e)}
                placeholder="From Year"
                required
              />
              <input
                className="form-input"
                type="text"
                name="yearto"
                value={exp.yearto}
                onChange={(e) => handleExperienceChange(index, e)}
                placeholder="To Year"
                required
              />
              <textarea
                className="form-textarea"
                name="description"
                value={exp.description}
                onChange={(e) => handleExperienceChange(index, e)}
                placeholder="Job Description"
                required
              />
              <label className="checkbox-label">
                Present:
                <input
                  className="checkbox-input"
                  type="checkbox"
                  name="present"
                  checked={exp.present}
                  onChange={(e) => {
                    const updatedExperience = [...formData.experience];
                    updatedExperience[index].present = e.target.checked;
                    setFormData({ ...formData, experience: updatedExperience });
                  }}
                />
              </label>
              <button type="button" className="remove-button" onClick={() => {
                const updatedExperience = [...formData.experience];
                updatedExperience.splice(index, 1);
                setFormData({ ...formData, experience: updatedExperience });
              }}>
                Remove
              </button>
            </div>
          ))}
          <button type="button" className="add-button" onClick={addExperience}>Add Experience</button>
        </div>

        {/* Education Section */}
        <div className="form-section">
          <h3>Education</h3>
          {formData.education.map((edu, index) => (
            <div className="education-item" key={index}>
              <input
                className="form-input"
                type="text"
                name="degree"
                value={edu.degree}
                onChange={(e) => handleEducationChange(index, e)}
                placeholder="Degree"
                required
              />
              <input
                className="form-input"
                type="text"
                name="university"
                value={edu.university}
                onChange={(e) => handleEducationChange(index, e)}
                placeholder="University"
                required
              />
              <input
                className="form-input"
                type="text"
                name="yearfrom"
                value={edu.yearfrom}
                onChange={(e) => handleEducationChange(index, e)}
                placeholder="From Year"
                required
              />
              <input
                className="form-input"
                type="text"
                name="yearto"
                value={edu.yearto}
                onChange={(e) => handleEducationChange(index, e)}
                placeholder="To Year"
                required
              />
              <input
                className="form-input"
                type="text"
                name="grade"
                value={edu.grade}
                onChange={(e) => handleEducationChange(index, e)}
                placeholder="Grade"
                required
              />
              <select
                className="form-input"
                name="gradetype"
                value={edu.gradetype}
                onChange={(e) => handleEducationChange(index, e)}
              >
                <option value="grade">Grade</option>
                <option value="percentage">Percentage</option>
              </select>
              <button type="button" className="remove-button" onClick={() => {
                const updatedEducation = [...formData.education];
                updatedEducation.splice(index, 1);
                setFormData({ ...formData, education: updatedEducation });
              }}>
                Remove
              </button>
            </div>
          ))}
          <button type="button" className="add-button" onClick={addEducation}>Add Education</button>
        </div>

        {/* Project Section */}
        <div className="form-section">
          <h3>Projects</h3>
          {formData.project.map((proj, index) => (
            <div className="project-item" key={index}>
              <input
                className="form-input"
                type="text"
                name="name"
                value={proj.name}
                onChange={(e) => handleProjectChange(index, e)}
                placeholder="Project Name"
                required
              />
              <input
                className="form-input"
                type="text"
                name="tech"
                value={proj.tech}
                onChange={(e) => handleProjectChange(index, e)}
                placeholder="Technologies"
                required
              />
              <textarea
                className="form-textarea"
                name="des"
                value={proj.des}
                onChange={(e) => handleProjectChange(index, e)}
                placeholder="Project Description"
                required
              />
              <button type="button" className="remove-button" onClick={() => {
                const updatedProjects = [...formData.project];
                updatedProjects.splice(index, 1);
                setFormData({ ...formData, project: updatedProjects });
              }}>
                Remove
              </button>
            </div>
          ))}
          <button type="button" className="add-button" onClick={addProject}>Add Project</button>
        </div>

        {/* Course Section */}
        <div className="form-section">
          <h3>Courses</h3>
          {formData.course.map((course, index) => (
            <div className="course-item" key={index}>
              <input
                className="form-input"
                type="text"
                name="name"
                value={course.name}
                onChange={(e) => handleCourseChange(index, e)}
                placeholder="Course Name"
                required
              />
              <input
                className="form-input"
                type="text"
                name="provider"
                value={course.provider}
                onChange={(e) => handleCourseChange(index, e)}
                placeholder="Course Provider"
                required
              />
              <button type="button" className="remove-button" onClick={() => {
                const updatedCourses = [...formData.course];
                updatedCourses.splice(index, 1);
                setFormData({ ...formData, course: updatedCourses });
              }}>
                Remove
              </button>
            </div>
          ))}
          <button type="button" className="add-button" onClick={addCourse}>Add Course</button>
        </div>

        <button type="submit" className="submit-button" onClick={handleSubmit}>Generate Resume</button>
      </form>
    </div>
  );
}

export default Input;
