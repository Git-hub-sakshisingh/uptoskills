import React from 'react';
import './TempDemo1.css';

function TempDemo1() {
  return (
    <div className="app">
    <div className="resume-container">
      <h1 className='h1'>Alta Parks</h1>
      <h2 className='h2'>Attorney</h2>

      <section className="contact">
        <h3>Contact</h3>
        <p>4567 Main Street<br />Brooklyn, New York 48127</p>
        <p>718.555.0100</p>
        <p>alta@example.com</p>
        <p>www.interestingsite.com</p>
      </section>

      <section className="profile">
        <h3>Profile</h3>
        <p>
          Analytical, energetic, and detail-oriented attorney with broad and
          deep experience in business and real estate matters, including business
          formation, real estate transactions, distressed property, due diligence,
          permitting, contract and lease negotiations, and landlord/tenant.
        </p>
      </section>

      <section className="education">
        <h3>Education</h3>
        <p><strong>Juris Doctor</strong> • June 20xx<br />Jasper University, Manhattan, NYC, New York<br />Real Estate Clinic, 1st place in Moot Court</p>
        <p><strong>BA in Political Science</strong> • June 20xx<br />Mount Flores College, Small Town, Massachusetts</p>
      </section>

      <section className="key-skills">
        <h3>Key Skills</h3>
        <ul>
          <li>Data analytics</li>
          <li>Records search</li>
          <li>Legal writing</li>
          <li>Excellent communication</li>
          <li>Organized</li>
        </ul>
      </section>

      <section className="interests">
        <h3>Interests</h3>
        <ul>
          <li>Literature</li>
          <li>Environmental conservation</li>
          <li>Art</li>
          <li>Yoga</li>
          <li>Skiing</li>
          <li>Travel</li>
        </ul>
      </section>

      <section className="experience">
        <h3>Experience</h3>
        <div>
          <p><strong>In-house counsel</strong> • March 20XX—present<br />Bandter Real Estate • NYC, New York</p>
          <p>
            Draft, negotiate, and enforce leases and purchase & sale agreements.
            Negotiate purchase and sale contracts for residential and commercial properties,
            including foreclosures. Handle landlord tenant issues including leasing, eviction, 
            and dispute resolution. Research, analyze and apply environmental, land use and zoning 
            laws. Oversee due diligence on real estate purchases. Work with outside counsel on legal matters.
          </p>
        </div>

        <div>
          <p><strong>Associate Attorney</strong> • Feb 20XX—Nov 20XX<br />Luca Udinesi Law firm • NYC, New York</p>
          <p>
            Represented and advised on small business, real estate, and landlord tenant issues.
            Researched and analyzed legal issues. Won $25,000 corporate dissolution litigation case.
          </p>
        </div>

        <div>
          <p><strong>Junior Associate Attorney</strong> • Sept 20XX—Jan 20XX<br />Law Offices of Keita Aoki • NYC, New York</p>
          <p>
            Researched legal issues and assisted in representation of clients on small business matters.
            Drafted legal memoranda. Assisted in multi-million-dollar telecom litigation as second chair.
          </p>
        </div>
      </section>
    </div>
    </div>
  );
}

export default TempDemo1;
