import { BrowserRouter as Router,Route,Routes } from 'react-router-dom';
import Login from './components/Login';
import Both from './components/Both';
import Home from './components/Home';
import Firstpage from './components/Firstpage';
import Suggestions from './components/Suggestion';
import Faq from './components/Faq';
import UploadPage from './components/UploadPage';
import Templates from './components/Templates';
import { useState } from 'react';
import AfterNo from  './components/AfterNo'
import Output from './components/Output';
import TemplateNo from './components/TemplateNo';
import FormPage from './components/Formpage';
import Input from './components/Input';
import { Provider } from 'react-redux';
import Classic from './Themes/Classic';


function App() {
  const [result,setResult]= useState({"name": "John Doe",
    "position": "Software Engineer",
    "skills": ["JavaScript", "React", "Node.js"]});

  return (
    <div>
      <Router>
      <Routes>
      {/* <Route exact path='/' element={ <Home/>}/>
     <Route exact path='/login' element={<Login/>}/>
     <Route exact path='/privacy' element={ <Both/>}/>
     <Route exact path='/faq' element={   <Faq/>}/>
     <Route exact path='/suggestion' element={ <Suggestions/>}/>
     <Route exact path='/firstpage' element={ <Firstpage/>}/>
     <Route exact path='/upload' element={ <UploadPage/>}/>
     <Route exact path='/afterno' element={<AfterNo setResult={setResult}/>}/>
    <Route exact path='/output' element={<Output result={result}/>}/>
    <Route exact path='/templateno' element={<TemplateNo/>}/>
     <Route exact path='/templates' element={<Templates/>}/>
     <Route exact path='/formpage' element={<FormPage/>}/> */}
     <Route exact path='/' element={<Input/>}/>
     <Route exact path='/classictheme' element={<Classic/>}/>
     </Routes>
     {/* <Provider></Provider> */}
     {/* <Input/> */}
      </Router>
    </div>
  );
}

export default App;
