const mongoose = require("mongoose");

const connectToMongo = async () => {
      try {
        await mongoose.connect(process.env.MONGODB_URI, { 
          // No need for useNewUrlParser and useUnifiedTopology
          serverSelectionTimeoutMS: 5000 // Option to set timeout for server selection
        });
        console.log("MongoDB connected successfully.");
      } catch (error) {
        console.error("Error connecting to MongoDB:", error);
      }
    };

    module.exports = connectToMongo;

    