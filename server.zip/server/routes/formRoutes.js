const express = require("express");
const routerForm = express.Router();
const { submitFormData } = require("../controllers/formControllers");

routerForm.post("/formdata", submitFormData);

module.exports = routerForm;





