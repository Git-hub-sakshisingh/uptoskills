// const mongoose = require("mongoose");

// const formSchema = new mongoose.Schema({
//   personal: {
//     name: { type: String },
//     lastname: { type: String },
//     mob: { type: String },
//     email: { type: String },
//     city: { type: String },
//     country: { type: String },
//     title: { type: String },
//     quote: { type: String },
//     technicalskill: [{ skill: String, rate: String }],
//     interest: [{ hobbie: String }],
//     languages: [{ language: String, proficiency: String }],
//     awards: [{ name: String, year: String, description: String }]
//   },
//   experience: [{
//     company: { type: String },
//     worktitle: { type: String },
//     yearfrom: { type: String },
//     yearto: { type: String },
//     description: { type: String }
//   }],
//   education: [{
//     degree: { type: String },
//     university: { type: String },
//     yearfrom: { type: String },
//     yearto: { type: String },
//     grade: { type: String }
//   }],
//   course: [{
//     name: { type: String },
//     provider: { type: String },
//     certificate: { type: String },
//     year: { type: String }
//   }],
//   project: [{
//     name: { type: String },
//     tech: { type: String },
//     des: { type: String },
//     link: { type: String }
//   }],
//   link: {
//     linkedin: { type: String },
//     github: { type: String },
//     portfolio: { type: String }
//   }
// });

// const FormData = mongoose.model("FormData", formSchema);

// module.exports = FormData;
const mongoose = require('mongoose');

const technicalSkillSchema = new mongoose.Schema({
  skill: String,
});

const interestSchema = new mongoose.Schema({
  hobbie: String,
});

const experienceSchema = new mongoose.Schema({
  company: String,
  worktitle: String,
  yearfrom: String,
  yearto: String,
  description: String,
  present: Boolean,
});

const educationSchema = new mongoose.Schema({
  degree: String,
  university: String,
  yearfrom: String,
  yearto: String,
  grade: String,
  gradetype: String,
});

const projectSchema = new mongoose.Schema({
  name: String,
  tech: String,
  des: String,
});

const courseSchema = new mongoose.Schema({
  name: String,
  provider: String,
});

const formSchema = new mongoose.Schema({
  personal: {
    name: String,
    lastname: String,
    title: String,
    quote: String,
    email: String,
    mob: String,
    city: String,
    country: String,
    technicalskill: [technicalSkillSchema],
    interest: [interestSchema],
  },
  link: {
    linkedin: String,
    github: String,
  },
  experience: [experienceSchema],
  education: [educationSchema],
  project: [projectSchema],
  course: [courseSchema],
});

const FormData = mongoose.model('FormData', formSchema);

module.exports = FormData;
