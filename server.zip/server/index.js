// const express = require("express");
// const cors = require("cors");
// const path = require("path");
// const mongoose = require("mongoose");
// require("dotenv").config();
// const resumeRoutes = require("./routes/resumeRoutes");

// const app = express();
// const PORT = process.env.PORT || 4000;


// const connectToMongo = async () => {
//   try {
//     await mongoose.connect(process.env.MONGODB_URI, { 
//       // No need for useNewUrlParser and useUnifiedTopology
//       serverSelectionTimeoutMS: 5000 // Option to set timeout for server selection
//     });
//     console.log("MongoDB connected successfully.");
//   } catch (error) {
//     console.error("Error connecting to MongoDB:", error);
//   }
// };
// connectToMongo();

// // Middleware
// app.use(express.urlencoded({ extended: true }));
// app.use(express.json());
// app.use(cors());
// // app.use("/uploads", express.static(path.join(__dirname, "/uploads")));
// // app.use(express.static(path.join(__dirname, "../client/build")));

// // Routes
// app.use("/output", resumeRoutes);

// // Serve React app for any unhandled routes (for production)
// app.get("*", (req, res) => {
//   res.sendFile(path.join(__dirname, "../enhancecv/public/index.html"));
// });

// // Start the server
// app.listen(PORT, () => {
//   console.log(`Server started on port: ${PORT}`);
// });
const express = require("express");
const cors = require("cors");
const bodyParser = require("body-parser");
const connectDB = require("./config/db");
const formRoutes = require("./routes/formRoutes");
const connectToMongo=require('./config/resumedb');
const resumeRoutes = require("./routes/resumeRoutes");

const app = express();
const port = 5000;

// Middleware
app.use(cors());
app.use(bodyParser.json());

// Connect to MongoDB
connectDB();
connectToMongo();

// Use routes
app.use("/api", formRoutes);
app.use("/output", resumeRoutes);

// Start server
app.listen(port, () => {
  console.log(`Server running on http://localhost:${port}`);
});
