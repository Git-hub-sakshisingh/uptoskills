const FormData = require("../models/FormData");

const submitFormData =async (req, res) => {
  try {
    const formData = new FormData(req.body);
    await formData.save();

    // Send a success response with JSON format
    res.status(201).json({ message: 'Data saved successfully', data: formData });
  } catch (error) {
    console.error('Error saving form data:', error);
    // Ensure that the error is sent back in JSON format
    res.status(500).json({ message: 'Error saving form data', error: error.message });
  }
};

module.exports = { submitFormData };

