const FormData = require("../models/FormData");

const submitFormData = async (req, res) => {
  try {
    const form = new FormData(req.body);
    await form.save();
    res.status(200).send("Data saved successfully");
  } catch (error) {
    console.error("Error saving form data:", error);
    res.status(500).send("Failed to save data");
  }
};

module.exports = { submitFormData };




// app.post('/api/formdata', async (req, res) => {
//   try {
//     const formData = new FormData(req.body);  // Create a new document from the request body
//     await formData.save();  // Save the data to MongoDB

//     // Send a proper JSON response
//     res.status(201).json({
//       message: 'Data saved successfully',
//       formData: formData,
//     });
//   } catch (error) {
//     console.error('Error saving data:', error);
//     res.status(500).json({
//       message: 'Error saving data',
//       error: error.message,
//     });
//   }
// });
